###SMS CENTER

A service for **sending** & **receiving** SMS

##_Under construction..._

#####Project Structure
![Project Structure](data/structure.png)